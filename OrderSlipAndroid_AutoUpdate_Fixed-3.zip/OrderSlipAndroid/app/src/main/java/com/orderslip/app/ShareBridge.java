package com.orderslip.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/** Native helpers the HTML calls as window.AndroidShare.* (WebView has no Web Share / file download). */
public class ShareBridge {
    private final Activity activity;

    ShareBridge(Activity activity) { this.activity = activity; }

    private static String cleanName(String name, String fallback) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "").trim();
        return n.isEmpty() ? fallback : n;
    }

    private void toast(final String msg) {
        activity.runOnUiThread(() -> Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show());
    }

    private File writeToCache(String folder, String name, byte[] bytes) throws Exception {
        File dir = new File(activity.getCacheDir(), folder);
        if (!dir.exists()) dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) f.delete();   // keep cache small
        File out = new File(dir, name);
        FileOutputStream fos = new FileOutputStream(out);
        try { fos.write(bytes); } finally { fos.close(); }
        return out;
    }

    private void openShareSheet(final Uri uri, final String mime, final String text) {
        activity.runOnUiThread(() -> {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                if (text != null && text.length() > 0) send.putExtra(Intent.EXTRA_TEXT, text);
                send.setClipData(ClipData.newRawUri("", uri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent chooser = Intent.createChooser(send, "Share order");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(chooser);
            } catch (Exception e) {
                Toast.makeText(activity, "Could not open share", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Send the order file through the Android share sheet (WhatsApp etc). */
    @JavascriptInterface
    public void shareHtml(String filename, String html, String text) {
        try {
            String name = cleanName(filename, "Order.html");
            File f = writeToCache("shared", name, html.getBytes("UTF-8"));
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
            openShareSheet(uri, "text/html", text);
        } catch (Exception e) {
            toast("Could not share order");
        }
    }

    /** Save a photo (data URL) to Pictures/OrderSlip. */
    @JavascriptInterface
    public void savePhoto(String filename, String dataUrl) {
        try {
            String name = cleanName(filename, "photo.jpg");
            byte[] bytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/OrderSlip");
                Uri uri = activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("insert failed");
                OutputStream os = activity.getContentResolver().openOutputStream(uri);
                try { os.write(bytes); } finally { os.close(); }
            } else {
                File f = writeToCache("shared", name, bytes);
                Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
                openShareSheet(uri, "image/jpeg", null);
            }
        } catch (Exception e) {
            toast("Could not save photo");
        }
    }
}
