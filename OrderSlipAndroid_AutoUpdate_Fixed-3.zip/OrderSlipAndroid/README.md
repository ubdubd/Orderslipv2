# Order Slip Android Project

This Android Studio project wraps the supplied `index.html` unchanged as a local WebView app.

- HTML source: `app/src/main/assets/index.html`
- JavaScript and localStorage remain inside the HTML.
- WebView enables JavaScript, DOM storage, file/content access, and file chooser support.
- Open this folder in Android Studio and build the APK with **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.

Note: the supplied HTML references `manifest.json` and external Google Fonts. The app still loads the exact HTML; those resources are not modified or substituted.
