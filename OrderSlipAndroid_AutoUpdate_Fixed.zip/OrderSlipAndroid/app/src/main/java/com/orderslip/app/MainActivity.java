package com.orderslip.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;
    private long downloadId = -1;
    private BroadcastReceiver downloadReceiver;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*");
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                startActivityForResult(pick, FILE_CHOOSER);
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        checkForUpdate();
    }

    private void checkForUpdate() {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                URL url = new URL("https://api.github.com/repos/ubdubd/Orderslipv2/releases/latest");
                c = (HttpURLConnection) url.openConnection();
                c.setRequestProperty("Accept", "application/vnd.github+json");
                c.setConnectTimeout(7000); c.setReadTimeout(7000);
                if (c.getResponseCode() != 200) return;
                BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                JSONObject obj = new JSONObject(sb.toString());
                String tag = obj.optString("tag_name", "");
                if (!tag.startsWith("v")) return;
                int remoteCode = Integer.parseInt(tag.substring(1).replaceAll("\\..*", ""));
                int localCode = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
                String apkUrl = "";
                for (int i = 0; i < obj.getJSONArray("assets").length(); i++) {
                    JSONObject a = obj.getJSONArray("assets").getJSONObject(i);
                    if (a.optString("name").equals("OrderSlip.apk")) { apkUrl = a.optString("browser_download_url"); break; }
                }
                if (remoteCode > localCode && !apkUrl.isEmpty()) {
                    final String finalUrl = apkUrl;
                    runOnUiThread(() -> showUpdateDialog(finalUrl, tag));
                }
            } catch (Exception ignored) { }
            finally { if (c != null) c.disconnect(); }
        }).start();
    }

    private void showUpdateDialog(String apkUrl, String version) {
        new AlertDialog.Builder(this)
            .setTitle("Order Slip Update Available")
            .setMessage("New version " + version + " is available. Update now?")
            .setNegativeButton("Later", null)
            .setPositiveButton("Update", (d, w) -> downloadUpdate(apkUrl))
            .show();
    }

    private void downloadUpdate(String apkUrl) {
        try {
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            Uri uri = Uri.parse(apkUrl);
            DownloadManager.Request req = new DownloadManager.Request(uri);
            req.setTitle("Order Slip update");
            req.setDescription("Downloading latest Order Slip APK");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "OrderSlip.apk");
            downloadId = dm.enqueue(req);
            downloadReceiver = new BroadcastReceiver() {
                @Override public void onReceive(Context context, Intent intent) {
                    long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                    if (id != downloadId) return;
                    try {
                        DownloadManager.Query q = new DownloadManager.Query().setFilterById(downloadId);
                        android.database.Cursor cur = dm.query(q);
                        if (cur != null && cur.moveToFirst()) {
                            int status = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                            cur.close();
                            if (status == DownloadManager.STATUS_SUCCESSFUL) installDownloadedApk();
                        }
                    } finally { unregisterReceiver(this); downloadReceiver = null; }
                }
            };
            registerReceiver(downloadReceiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), Context.RECEIVER_NOT_EXPORTED);
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("Update failed").setMessage("Could not download the update.").setPositiveButton("OK", null).show();
        }
    }

    private void installDownloadedApk() {
        java.io.File apk = new java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "OrderSlip.apk");
        if (!apk.exists()) return;
        if (android.os.Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
            startActivity(settings);
            new AlertDialog.Builder(this).setTitle("Allow installation").setMessage("Allow Order Slip to install updates, then tap the update again.").setPositiveButton("OK", null).show();
            return;
        }
        Uri contentUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(contentUri, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null && data.getClipData().getItemCount() > 0) result = new Uri[]{data.getClipData().getItemAt(0).getUri()};
                else if (data.getData() != null) result = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result); fileCallback = null;
        }
    }
    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
